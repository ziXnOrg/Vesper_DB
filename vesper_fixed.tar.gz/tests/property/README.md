# Property Tests

This directory will contain property-based tests (invariants and round-trips). We will use Catch2 generators and simple custom generators, keeping seeds deterministic as per algorithms/spec/tolerances.md.

