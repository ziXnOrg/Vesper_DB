# Error taxonomy (Draft)

Scope
- Summarize error codes and their meanings to support test design and API contracts. No behavior change.

Conventions
- C++23; std::expected for error returns; portable
- Error domains should have stable string code and enum value
- Logging: include `component` and `context` fields (no PII)

WAL error codes (observed in tests)
- io: I/O failures such as missing file, permission denied (e.g., missing wal-*.log or unreadable manifest)
- data_integrity: corruption detected in non-last WAL file (e.g., truncated/mid-file flip)
- torn_tail_allowed: truncation in the last file is tolerated (not an error)
- manifest_stale: manifest may be out-of-date; recovery should still include highest-seq file (advisory)
- invalid_header: bad or mismatched header (e.g., manifest header mismatch)

Mapping used in tests
- recover_scan_dir: returns data_integrity for corruption in non-last file; returns io for missing files; tolerates torn tail on last
- purge_wal: removes files fully covered by cutoff; idempotent under stale manifest

Notes
- This doc describes current semantics validated by tests; production code remains the source of truth.
- Future phases may formalize error categories and Doxygen docs once API/ABI freeze.

