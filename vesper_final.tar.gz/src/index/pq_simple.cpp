#include "vesper/index/pq_simple.hpp"
#include "vesper/index/kmeans.hpp"
#include "vesper/kernels/dispatch.hpp"

#include <algorithm>
#include <numeric>
#include <cmath>

namespace vesper::index {

SimplePq::SimplePq(const FastScanPqConfig& config)
    : m_(config.m)
    , nbits_(config.nbits)
    , ksub_(1U << config.nbits)
    , dsub_(0)
    , trained_(false) {
}

SimplePq::~SimplePq() = default;

auto SimplePq::train(const float* data, std::size_t n, std::size_t dim)
    -> std::expected<void, core::error> {
    using core::error;
    using core::error_code;
    
    if (dim % m_ != 0) {
        return std::vesper_unexpected(error{
            error_code::precondition_failed,
            "Dimension must be divisible by number of subquantizers",
            "pq_simple"
        });
    }
    
    if (n < ksub_ * m_) {
        return std::vesper_unexpected(error{
            error_code::precondition_failed,
            "Need at least ksub * m training vectors",
            "pq_simple"
        });
    }
    
    dsub_ = dim / m_;
    
    // Allocate codebooks
    codebooks_ = std::make_unique<AlignedCentroidBuffer>(m_ * ksub_, dsub_);
    
    // Train each subquantizer independently
    for (std::uint32_t sq = 0; sq < m_; ++sq) {
        // Extract subvectors for this subquantizer
        std::vector<float> subvectors(n * dsub_);
        
        for (std::size_t i = 0; i < n; ++i) {
            std::copy(data + i * dim + sq * dsub_,
                     data + i * dim + (sq + 1) * dsub_,
                     subvectors.data() + i * dsub_);
        }
        
        // Run k-means on subvectors
        KmeansParams params{
            .k = ksub_,
            .max_iter = 20,
            .epsilon = 1e-4f,
            .seed = 42 + sq
        };
        
        auto result = kmeans_cluster(subvectors.data(), n, dsub_, params);
        if (!result.has_value()) {
            return std::vesper_unexpected(error{
                error_code::internal,
                "K-means clustering failed for subquantizer",
                "pq_simple"
            });
        }
        
        // Copy centroids to codebook
        for (std::uint32_t c = 0; c < ksub_; ++c) {
            auto* dst = codebooks_->data() + (sq * ksub_ + c) * dsub_;
            auto* src = result->centroids[c].data();
            std::copy(src, src + dsub_, dst);
        }
    }
    
    trained_ = true;
    return {};
}

auto SimplePq::encode(const float* data, std::size_t n, std::uint8_t* codes) const -> void {
    if (!trained_) return;
    
    const auto& ops = kernels::select_backend_auto();
    
    for (std::size_t i = 0; i < n; ++i) {
        for (std::uint32_t sq = 0; sq < m_; ++sq) {
            // Find nearest centroid for this subvector
            const float* subvec = data + i * (m_ * dsub_) + sq * dsub_;
            
            float min_dist = std::numeric_limits<float>::max();
            std::uint8_t best_idx = 0;
            
            for (std::uint32_t c = 0; c < ksub_; ++c) {
                const float* centroid = codebooks_->data() + (sq * ksub_ + c) * dsub_;
                
                float dist = ops.l2_sq(
                    std::span(subvec, dsub_),
                    std::span(centroid, dsub_)
                );
                
                if (dist < min_dist) {
                    min_dist = dist;
                    best_idx = static_cast<std::uint8_t>(c);
                }
            }
            
            codes[i * m_ + sq] = best_idx;
        }
    }
}

auto SimplePq::compute_lookup_tables(const float* query) const -> std::vector<float> {
    if (!trained_) return {};
    
    const auto& ops = kernels::select_backend_auto();
    std::vector<float> tables(m_ * ksub_);
    
    for (std::uint32_t sq = 0; sq < m_; ++sq) {
        const float* subquery = query + sq * dsub_;
        
        for (std::uint32_t c = 0; c < ksub_; ++c) {
            const float* centroid = codebooks_->data() + (sq * ksub_ + c) * dsub_;
            
            // Compute L2 distance between subquery and centroid
            float dist = ops.l2_sq(
                std::span(subquery, dsub_),
                std::span(centroid, dsub_)
            );
            
            tables[sq * ksub_ + c] = dist;
        }
    }
    
    return tables;
}

auto SimplePq::compute_distance(const std::uint8_t* codes, const float* tables) const -> float {
    float dist = 0.0f;
    
    for (std::uint32_t sq = 0; sq < m_; ++sq) {
        std::uint8_t code = codes[sq];
        dist += tables[sq * ksub_ + code];
    }
    
    return dist;
}

} // namespace vesper::index