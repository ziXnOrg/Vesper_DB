#include "vesper/index/kmeans_elkan.hpp"
#include "vesper/kernels/dispatch.hpp"
#include "vesper/kernels/batch_distances.hpp"
#include "vesper/core/memory_pool.hpp"

#include <algorithm>
#include <chrono>
#include <limits>
#include <numeric>
#include <random>
#include <execution>
#include <cmath>
#include <thread>

namespace vesper::index {

namespace {

/** \brief Compute squared L2 distance using SIMD kernels. */
[[gnu::hot, gnu::always_inline]] 
inline auto compute_distance(const float* a, const float* b, std::size_t dim) -> float {
    const auto& ops = kernels::select_backend_auto();
    return ops.l2_sq(std::span(a, dim), std::span(b, dim));
}

/** \brief Update centroid from assigned points. */
auto update_centroid(const float* data, std::size_t dim,
                    const std::vector<std::size_t>& indices,
                    std::vector<float>& centroid) -> void {
    if (indices.empty()) return;
    
    std::fill(centroid.begin(), centroid.end(), 0.0f);
    
    // Accumulate with Kahan summation for numerical stability
    std::vector<double> sum(dim, 0.0);
    std::vector<double> c(dim, 0.0);  // Compensation
    
    for (std::size_t idx : indices) {
        const float* point = data + idx * dim;
        for (std::size_t d = 0; d < dim; ++d) {
            double y = point[d] - c[d];
            double t = sum[d] + y;
            c[d] = (t - sum[d]) - y;
            sum[d] = t;
        }
    }
    
    const double scale = 1.0 / static_cast<double>(indices.size());
    for (std::size_t d = 0; d < dim; ++d) {
        centroid[d] = static_cast<float>(sum[d] * scale);
    }
}

} // anonymous namespace

auto KmeansElkan::compute_distance_instrumented(const float* a, const float* b, 
                                               std::size_t dim) -> float {
    distance_counter_.fetch_add(1, std::memory_order_relaxed);
    return compute_distance(a, b, dim);
}

auto KmeansElkan::initialize_bounds(const float* data, std::size_t n, std::size_t dim,
                                   const std::vector<std::vector<float>>& centroids)
    -> std::vector<PointBounds> {
    const std::uint32_t k = centroids.size();
    std::vector<PointBounds> bounds(n);
    
    #pragma omp parallel for schedule(dynamic, 256)
    for (std::size_t i = 0; i < n; ++i) {
        const float* point = data + i * dim;
        bounds[i].lower.resize(k);
        
        // Find nearest centroid and compute all distances
        float min_dist = std::numeric_limits<float>::max();
        std::uint32_t best_c = 0;
        
        for (std::uint32_t c = 0; c < k; ++c) {
            const float dist = compute_distance_instrumented(
                point, centroids[c].data(), dim);
            bounds[i].lower[c] = dist;
            
            if (dist < min_dist) {
                min_dist = dist;
                best_c = c;
            }
        }
        
        bounds[i].upper = min_dist;
        bounds[i].assignment = best_c;
        bounds[i].upper_tight = true;
    }
    
    return bounds;
}

auto KmeansElkan::update_centroid_distances(
    const std::vector<std::vector<float>>& centroids)
    -> std::pair<std::vector<std::vector<float>>, std::vector<float>> {
    
    const std::uint32_t k = centroids.size();
    const std::size_t dim = centroids[0].size();
    
    // Compute inter-centroid distances
    std::vector<std::vector<float>> dist(k, std::vector<float>(k, 0.0f));
    
    #pragma omp parallel for collapse(2) if(k > 16)
    for (std::uint32_t i = 0; i < k; ++i) {
        for (std::uint32_t j = i + 1; j < k; ++j) {
            const float d = compute_distance(
                centroids[i].data(), centroids[j].data(), dim);
            dist[i][j] = d;
            dist[j][i] = d;
        }
    }
    
    // Compute s values (half minimum distance to other centroids)
    std::vector<float> s_half(k);
    for (std::uint32_t i = 0; i < k; ++i) {
        float min_dist = std::numeric_limits<float>::max();
        for (std::uint32_t j = 0; j < k; ++j) {
            if (i != j && dist[i][j] < min_dist) {
                min_dist = dist[i][j];
            }
        }
        s_half[i] = min_dist * 0.5f;
    }
    
    return {dist, s_half};
}

auto KmeansElkan::update_centroid_distances_aligned(
    const AlignedCentroidBuffer& centroids)
    -> std::pair<AlignedDistanceMatrix, std::vector<float>> {
    
    const std::uint32_t k = centroids.size();
    
    AlignedDistanceMatrix dist(k);
    
    // Use SIMD-optimized symmetric distance matrix computation
    kernels::compute_symmetric_distance_matrix(centroids, dist);
    
    // Compute s values with vectorized min
    std::vector<float> s_half(k);
    
    #pragma omp parallel for
    for (std::uint32_t i = 0; i < k; ++i) {
        const auto row = dist.row(i);
        float min_dist = std::numeric_limits<float>::max();
        
        // Unrolled loop for better vectorization
        std::uint32_t j = 0;
        for (; j + 4 <= k; j += 4) {
            if (j != i && j + 1 != i && j + 2 != i && j + 3 != i) {
                min_dist = std::min({min_dist, row[j], row[j+1], row[j+2], row[j+3]});
            } else {
                // Handle cases where i is in this block
                for (std::uint32_t jj = j; jj < j + 4; ++jj) {
                    if (jj != i) {
                        min_dist = std::min(min_dist, row[jj]);
                    }
                }
            }
        }
        
        // Handle remainder
        for (; j < k; ++j) {
            if (j != i) {
                min_dist = std::min(min_dist, row[j]);
            }
        }
        
        s_half[i] = min_dist * 0.5f;
    }
    
    return {std::move(dist), s_half};
}

auto KmeansElkan::assign_with_bounds(const float* data, std::size_t n, std::size_t dim,
                                    const std::vector<std::vector<float>>& centroids,
                                    std::vector<PointBounds>& bounds,
                                    const std::vector<float>& s_half)
    -> float {
    const std::uint32_t k = centroids.size();
    std::atomic<double> total_inertia{0.0};
    
    #pragma omp parallel for schedule(dynamic, 256) reduction(+:total_inertia)
    for (std::size_t i = 0; i < n; ++i) {
        const float* point = data + i * dim;
        auto& b = bounds[i];
        
        // Step 3a: If upper bound indicates we can skip
        if (b.upper <= s_half[b.assignment]) {
            skip_counter_.fetch_add(k - 1, std::memory_order_relaxed);
            total_inertia += b.upper;
            continue;
        }
        
        // Step 3b: Tighten upper bound if needed
        if (!b.upper_tight) {
            const float actual_dist = compute_distance_instrumented(
                point, centroids[b.assignment].data(), dim);
            b.lower[b.assignment] = actual_dist;
            b.upper = actual_dist;
            b.upper_tight = true;
            
            if (b.upper <= s_half[b.assignment]) {
                skip_counter_.fetch_add(k - 1, std::memory_order_relaxed);
                total_inertia += b.upper;
                continue;
            }
        }
        
        // Step 3c: Check other centroids using lower bounds
        bool changed = false;
        for (std::uint32_t c = 0; c < k; ++c) {
            if (c == b.assignment) continue;
            
            // Skip if lower bound indicates this centroid is too far
            if (b.upper <= b.lower[c]) {
                skip_counter_.fetch_add(1, std::memory_order_relaxed);
                continue;
            }
            
            // Skip if centroid is definitely farther
            if (b.upper <= 0.5f * inter_centroid_dist_cache_[b.assignment][c]) {
                skip_counter_.fetch_add(1, std::memory_order_relaxed);
                continue;
            }
            
            // Must compute actual distance
            const float dist = compute_distance_instrumented(
                point, centroids[c].data(), dim);
            b.lower[c] = dist;
            
            if (dist < b.upper) {
                // Found closer centroid
                b.assignment = c;
                b.upper = dist;
                b.upper_tight = true;
                changed = true;
            }
        }
        
        total_inertia += b.upper;
    }
    
    return static_cast<float>(total_inertia);
}

auto KmeansElkan::update_bounds(std::vector<PointBounds>& bounds,
                              const std::vector<float>& centroid_shift,
                              const std::vector<std::vector<float>>& inter_centroid_dist) {
    const std::uint32_t k = centroid_shift.size();
    
    // Find maximum shift for bound updates
    float max_shift = *std::max_element(centroid_shift.begin(), centroid_shift.end());
    
    #pragma omp parallel for
    for (auto& b : bounds) {
        // Update upper bound
        b.upper += centroid_shift[b.assignment];
        b.upper_tight = false;
        
        // Update lower bounds
        for (std::uint32_t c = 0; c < k; ++c) {
            b.lower[c] = std::max(0.0f, b.lower[c] - centroid_shift[c]);
        }
    }
}

auto KmeansElkan::cluster(const float* data, std::size_t n, std::size_t dim,
                         const Config& config)
    -> std::expected<KmeansResult, core::error> {
    using core::error;
    using core::error_code;
    
    if (n < config.k) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "Not enough data points for k clusters",
            "kmeans_elkan"
        });
    }
    
    const auto start_time = std::chrono::steady_clock::now();
    
    // Reset statistics
    distance_counter_ = 0;
    skip_counter_ = 0;
    
    // Initialize centroids using k-means++
    auto centroids = kmeans_plusplus_init(data, n, dim, config.k, config.seed);
    
    // Initialize bounds
    auto bounds = initialize_bounds(data, n, dim, centroids);
    
    // Cache inter-centroid distances
    auto [inter_dist, s_half] = update_centroid_distances(centroids);
    inter_centroid_dist_cache_ = inter_dist;
    
    float prev_inertia = std::numeric_limits<float>::max();
    std::uint32_t iter = 0;
    
    for (; iter < config.max_iter; ++iter) {
        // E-step: Assign points using bounds
        const float inertia = assign_with_bounds(data, n, dim, centroids, bounds, s_half);
        
        // Check convergence
        const float change = std::abs(prev_inertia - inertia) / (prev_inertia + 1e-10f);
        if (change < config.epsilon) {
            break;
        }
        prev_inertia = inertia;
        
        // M-step: Update centroids with pooled memory
        core::PoolScope pool_scope;
        auto cluster_indices = core::make_pooled_vector<
            core::PooledVector<std::size_t>>(config.k);
        for (auto& indices : cluster_indices) {
            indices.reserve(n / config.k + 1);  // Estimate size
        }
        
        for (std::size_t i = 0; i < n; ++i) {
            cluster_indices[bounds[i].assignment].push_back(i);
        }
        
        std::vector<float> centroid_shift(config.k);
        #pragma omp parallel for
        for (std::uint32_t c = 0; c < config.k; ++c) {
            std::vector<float> old_centroid = centroids[c];
            // Convert PooledVector to std::vector for the function call
            std::vector<std::size_t> indices(cluster_indices[c].begin(), 
                                            cluster_indices[c].end());
            update_centroid(data, dim, indices, centroids[c]);
            centroid_shift[c] = compute_distance(
                old_centroid.data(), centroids[c].data(), dim);
        }
        
        // Update bounds
        update_bounds(bounds, centroid_shift, inter_dist);
        
        // Update inter-centroid distances
        std::tie(inter_dist, s_half) = update_centroid_distances(centroids);
        inter_centroid_dist_cache_ = inter_dist;
    }
    
    // Prepare result
    std::vector<std::uint32_t> assignments(n);
    std::vector<std::uint32_t> cluster_sizes(config.k, 0);
    for (std::size_t i = 0; i < n; ++i) {
        assignments[i] = bounds[i].assignment;
        cluster_sizes[bounds[i].assignment]++;
    }
    
    const auto end_time = std::chrono::steady_clock::now();
    const auto duration = std::chrono::duration<float>(end_time - start_time);
    
    // Update statistics
    stats_.distance_computations = distance_counter_.load();
    stats_.distance_skipped = skip_counter_.load();
    const auto total_possible = n * config.k * iter;
    stats_.skip_rate = static_cast<float>(stats_.distance_skipped) / 
                       static_cast<float>(total_possible);
    stats_.iterations = iter;
    stats_.final_inertia = prev_inertia;
    stats_.time_sec = duration.count();
    
    return KmeansResult{
        .centroids = std::move(centroids),
        .assignments = std::move(assignments),
        .cluster_sizes = std::move(cluster_sizes),
        .inertia = prev_inertia,
        .iterations = iter,
        .time_sec = duration.count()
    };
}

// Private member for caching
std::vector<std::vector<float>> KmeansElkan::inter_centroid_dist_cache_;

auto kmeans_parallel_init(const float* data, std::size_t n, std::size_t dim,
                          std::uint32_t k, std::uint32_t rounds,
                          std::uint32_t seed)
    -> std::vector<std::vector<float>> {
    std::mt19937 gen(seed);
    
    // Start with one random center
    std::uniform_int_distribution<std::size_t> first_dist(0, n - 1);
    std::vector<std::vector<float>> centers;
    const std::size_t first_idx = first_dist(gen);
    centers.emplace_back(data + first_idx * dim, data + (first_idx + 1) * dim);
    
    // Oversampling factor
    const std::size_t l = std::max(k, std::uint32_t(2 * std::log(n)));
    
    for (std::uint32_t round = 0; round < rounds && centers.size() < k; ++round) {
        // Compute distances to nearest center
        std::vector<float> min_distances(n);
        
        #pragma omp parallel for
        for (std::size_t i = 0; i < n; ++i) {
            const float* point = data + i * dim;
            float min_dist = std::numeric_limits<float>::max();
            
            for (const auto& center : centers) {
                const float dist = compute_distance(point, center.data(), dim);
                min_dist = std::min(min_dist, dist);
            }
            min_distances[i] = min_dist;
        }
        
        // Sample new centers proportional to squared distance
        const float sum_dist = std::accumulate(min_distances.begin(), 
                                              min_distances.end(), 0.0f);
        
        std::uniform_real_distribution<float> sample_dist(0.0f, sum_dist);
        const std::size_t new_centers = std::min(l, k - centers.size());
        
        for (std::size_t c = 0; c < new_centers; ++c) {
            float target = sample_dist(gen);
            float cumsum = 0.0f;
            
            for (std::size_t i = 0; i < n; ++i) {
                cumsum += min_distances[i];
                if (cumsum >= target) {
                    centers.emplace_back(data + i * dim, data + (i + 1) * dim);
                    break;
                }
            }
        }
    }
    
    // If we have more than k centers, cluster them down to k
    if (centers.size() > k) {
        KmeansElkan elkan;
        KmeansElkan::Config config{.k = k, .seed = seed};
        
        // Flatten centers for clustering
        std::vector<float> center_data(centers.size() * dim);
        for (std::size_t i = 0; i < centers.size(); ++i) {
            std::copy(centers[i].begin(), centers[i].end(), 
                     center_data.begin() + i * dim);
        }
        
        auto result = elkan.cluster(center_data.data(), centers.size(), dim, config);
        if (result.has_value()) {
            return result->centroids;
        }
    }
    
    return centers;
}

} // namespace vesper::index