#!/bin/bash

# Simple Vast.ai Performance Testing Script for Vesper
# Usage: ./run_vast_test_simple.sh

set -euo pipefail

# Configuration
VAST_CLI="$HOME/.local/bin/vastai"
SSH_KEY="$HOME/.ssh/vast_ai_key"
RESULTS_DIR="vast_results_$(date +%Y%m%d_%H%M%S)"

echo "======================================"
echo "   Vast.ai Performance Test Runner   "
echo "======================================"

# Step 1: Find and create instance
echo "[1/6] Finding suitable instance with AVX2 support..."

# Look for CPU-only instances with good specs
INSTANCE_ID=$($VAST_CLI search offers \
    --type on-demand \
    --no-gpus \
    --storage 10 \
    --ram 16 \
    --cpu 8 \
    --order cpu_ram \
    --limit 5 \
    2>/dev/null | grep -E "^[0-9]+" | head -1 | awk '{print $1}')

if [ -z "$INSTANCE_ID" ]; then
    echo "Error: No suitable instances found"
    exit 1
fi

echo "Found instance ID: $INSTANCE_ID"

# Create the instance
echo "[2/6] Creating instance..."
CONTRACT_ID=$($VAST_CLI create instance $INSTANCE_ID \
    --image pytorch/pytorch:latest \
    --disk 20 \
    --ssh \
    2>&1 | grep -oP '(?<=Instance created: )\d+' || echo "")

if [ -z "$CONTRACT_ID" ]; then
    echo "Error: Failed to create instance"
    exit 1
fi

echo "Created contract: $CONTRACT_ID"
echo "$CONTRACT_ID" > .vast_contract

# Wait for instance to be ready
echo "[3/6] Waiting for instance to start (this may take 2-3 minutes)..."
sleep 30

for i in {1..20}; do
    STATUS=$($VAST_CLI show instances --raw 2>/dev/null | jq -r ".[] | select(.id==$CONTRACT_ID) | .actual_status" || echo "")
    if [ "$STATUS" = "running" ]; then
        echo "Instance is running!"
        break
    fi
    echo -n "."
    sleep 10
done

if [ "$STATUS" != "running" ]; then
    echo "Warning: Instance may not be fully ready"
fi

# Get SSH details
echo "[4/6] Getting SSH connection details..."
SSH_URL=$($VAST_CLI ssh-url $CONTRACT_ID 2>/dev/null || echo "")

if [ -z "$SSH_URL" ]; then
    echo "Error: Could not get SSH URL"
    $VAST_CLI destroy instance $CONTRACT_ID
    rm -f .vast_contract
    exit 1
fi

# Parse SSH URL (format: ssh -p PORT root@HOST)
SSH_PORT=$(echo "$SSH_URL" | grep -oP '(?<=-p )\d+')
SSH_HOST=$(echo "$SSH_URL" | grep -oP '(?<=@)[^\s]+')
SSH_USER="root"

echo "Connecting to $SSH_HOST:$SSH_PORT"

# Setup SSH command
SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null $SSH_USER@$SSH_HOST"
SCP_CMD="scp -i $SSH_KEY -P $SSH_PORT -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

# Wait for SSH to be available
echo "[5/6] Waiting for SSH access..."
for i in {1..30}; do
    if $SSH_CMD "echo 'Connected'" 2>/dev/null; then
        echo "SSH connection established!"
        break
    fi
    echo -n "."
    sleep 5
done

# Setup and run tests
echo "[6/6] Running performance tests..."

# Create test script to run on remote
cat > remote_test.sh << 'SCRIPT_END'
#!/bin/bash
set -e

# Install dependencies
apt-get update
apt-get install -y build-essential cmake git g++ wget

# Check CPU features
echo "=== CPU Information ==="
lscpu | grep -E "Model name|CPU|Thread|Core|cache"
echo ""
echo "=== SIMD Support ==="
grep -o 'avx[^ ]*' /proc/cpuinfo | sort -u || echo "No AVX"
grep -o 'sse[^ ]*' /proc/cpuinfo | sort -u || echo "No SSE"
echo ""

# Get Vesper code (we'll send it as tarball)
cd /root
tar xzf vesper.tar.gz
cd Vesper

# Build
echo "=== Building Vesper ==="
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS="-O3 -march=native"
make vesper_core -j$(nproc)

# Build tests
echo "=== Building Tests ==="
g++ -std=c++20 -O3 -march=native -I../include -o perf_test \
    ../tests/unit/actual_index_performance_test.cpp \
    libvesper_core.a -pthread

g++ -std=c++20 -O3 -march=native -I../include -o minimal_test \
    ../tests/unit/minimal_test.cpp \
    libvesper_core.a -pthread

# Run tests
echo "=== Running Tests ==="
./minimal_test
echo ""
./perf_test

echo "=== Tests Complete ==="
SCRIPT_END

# Create tarball of repository
echo "Creating repository archive..."
tar czf vesper.tar.gz \
    --exclude='build*' \
    --exclude='.git' \
    --exclude='vast_*' \
    -C .. Vesper

# Upload files
echo "Uploading code..."
$SCP_CMD vesper.tar.gz "$SSH_USER@$SSH_HOST:/root/"
$SCP_CMD remote_test.sh "$SSH_USER@$SSH_HOST:/root/"

# Run the test script and capture output
echo "Running tests on remote instance..."
mkdir -p "$RESULTS_DIR"
$SSH_CMD "chmod +x /root/remote_test.sh && /root/remote_test.sh" | tee "$RESULTS_DIR/test_output.txt"

# Get system info
$SSH_CMD "lscpu" > "$RESULTS_DIR/cpu_info.txt"

# Cleanup
echo ""
echo "======================================"
echo "Cleaning up..."
$VAST_CLI destroy instance $CONTRACT_ID
rm -f .vast_contract vesper.tar.gz remote_test.sh

echo ""
echo "======================================"
echo "Test complete! Results saved in $RESULTS_DIR/"
echo ""

# Show summary
if grep -q "ALL TARGETS MET" "$RESULTS_DIR/test_output.txt"; then
    echo "✅ Performance targets achieved!"
else
    echo "⚠️  Some performance targets not met"
fi

echo ""
grep -E "(Build rate|Search P|Memory:)" "$RESULTS_DIR/test_output.txt" | tail -20