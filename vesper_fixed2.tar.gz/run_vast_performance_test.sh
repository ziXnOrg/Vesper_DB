#!/bin/bash

# Vast.ai Performance Testing Script for Vesper
# This script automates spinning up a vast.ai instance, running performance tests,
# and collecting results for the Vesper vector search engine.

set -euo pipefail

# Configuration
VAST_CLI="$HOME/.local/bin/vastai"
SSH_KEY="$HOME/.ssh/vast_ai_key"
REPO_URL="https://github.com/yourusername/vesper.git"  # Update with actual repo
LOCAL_REPO_PATH="$(pwd)"
RESULTS_DIR="vast_test_results_$(date +%Y%m%d_%H%M%S)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
    exit 1
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    log "Checking prerequisites..."
    
    if [ ! -f "$VAST_CLI" ]; then
        error "vast CLI not found at $VAST_CLI"
    fi
    
    if [ ! -f "$SSH_KEY" ]; then
        error "SSH key not found at $SSH_KEY"
    fi
    
    # Check if we're logged in to vast.ai
    if ! $VAST_CLI show user >/dev/null 2>&1; then
        error "Not logged in to vast.ai. Run: vastai login"
    fi
    
    log "Prerequisites check passed"
}

# Find and rent a suitable instance
rent_instance() {
    log "Searching for suitable instances with AVX2/AVX-512 support..."
    
    # Search for instances with:
    # - At least 8 CPU cores
    # - At least 16GB RAM
    # - Ubuntu 22.04
    # - Good CPU performance (preferably Intel/AMD with AVX2)
    # - Reasonable price
    
    INSTANCE_QUERY='{
        "verified": {"eq": true},
        "rentable": {"eq": true},
        "num_gpus": {"eq": 0},
        "cpu_cores_effective": {"gte": 8},
        "cpu_ram": {"gte": 16},
        "inet_down": {"gte": 100},
        "dph_total": {"lte": 0.50}
    }'
    
    # Find best instance
    INSTANCE_ID=$($VAST_CLI search offers "$INSTANCE_QUERY" \
        --limit 10 \
        --order "cpu_cores_effective-" \
        | jq -r 'select(.cpu_name | test("Intel|AMD")) | select(.cpu_name | test("Xeon|EPYC|Core")) | .id' \
        | head -1)
    
    if [ -z "$INSTANCE_ID" ]; then
        error "No suitable instances found"
    fi
    
    log "Found suitable instance: $INSTANCE_ID"
    
    # Create instance with Ubuntu image
    log "Creating instance..."
    INSTANCE_INFO=$($VAST_CLI create instance $INSTANCE_ID \
        --image "ubuntu:22.04" \
        --disk 20 \
        --ssh \
        --raw)
    
    CONTRACT_ID=$(echo "$INSTANCE_INFO" | jq -r '.new_contract')
    
    if [ -z "$CONTRACT_ID" ]; then
        error "Failed to create instance"
    fi
    
    log "Instance created with contract ID: $CONTRACT_ID"
    
    # Wait for instance to be ready
    log "Waiting for instance to be ready..."
    for i in {1..30}; do
        STATUS=$($VAST_CLI show instance $CONTRACT_ID | jq -r '.actual_status')
        if [ "$STATUS" = "running" ]; then
            break
        fi
        sleep 10
        echo -n "."
    done
    echo
    
    if [ "$STATUS" != "running" ]; then
        error "Instance failed to start"
    fi
    
    # Get SSH connection info
    SSH_INFO=$($VAST_CLI ssh-url $CONTRACT_ID)
    SSH_HOST=$(echo "$SSH_INFO" | cut -d'@' -f2 | cut -d':' -f1)
    SSH_PORT=$(echo "$SSH_INFO" | cut -d':' -f2)
    SSH_USER=$(echo "$SSH_INFO" | cut -d'@' -f1)
    
    log "Instance ready at $SSH_HOST:$SSH_PORT"
    
    echo "$CONTRACT_ID" > .vast_contract_id
    echo "$SSH_HOST:$SSH_PORT:$SSH_USER" > .vast_ssh_info
}

# Setup the instance
setup_instance() {
    log "Setting up instance..."
    
    local SSH_INFO=$(cat .vast_ssh_info)
    local SSH_HOST=$(echo "$SSH_INFO" | cut -d':' -f1)
    local SSH_PORT=$(echo "$SSH_INFO" | cut -d':' -f2)
    local SSH_USER=$(echo "$SSH_INFO" | cut -d':' -f3)
    
    SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no $SSH_USER@$SSH_HOST"
    
    # Wait for SSH to be available
    log "Waiting for SSH..."
    for i in {1..30}; do
        if $SSH_CMD "echo 'SSH ready'" 2>/dev/null; then
            break
        fi
        sleep 5
        echo -n "."
    done
    echo
    
    # Install dependencies
    log "Installing dependencies..."
    $SSH_CMD << 'ENDSSH'
        set -e
        
        # Update system
        sudo apt-get update
        
        # Install build tools
        sudo apt-get install -y \
            build-essential \
            cmake \
            git \
            ninja-build \
            libomp-dev \
            clang-14 \
            wget \
            curl
        
        # Install Google Test
        sudo apt-get install -y libgtest-dev
        
        # Check CPU features
        echo "=== CPU Information ==="
        lscpu | grep -E "Model name|CPU\(s\)|Thread|Core|Socket|MHz|cache|Flags"
        
        # Check for AVX support
        echo "=== SIMD Support ==="
        grep -o 'avx[^ ]*' /proc/cpuinfo | sort -u || echo "No AVX support found"
        grep -o 'sse[^ ]*' /proc/cpuinfo | sort -u || echo "No SSE support found"
ENDSSH
    
    log "Instance setup complete"
}

# Upload repository
upload_repository() {
    log "Uploading repository..."
    
    local SSH_INFO=$(cat .vast_ssh_info)
    local SSH_HOST=$(echo "$SSH_INFO" | cut -d':' -f1)
    local SSH_PORT=$(echo "$SSH_INFO" | cut -d':' -f2)
    local SSH_USER=$(echo "$SSH_INFO" | cut -d':' -f3)
    
    # Create a tarball of the repository (excluding build directories)
    log "Creating repository archive..."
    tar czf vesper_repo.tar.gz \
        --exclude='build*' \
        --exclude='.git' \
        --exclude='*.o' \
        --exclude='*.a' \
        --exclude='vast_test_results*' \
        -C "$(dirname "$LOCAL_REPO_PATH")" \
        "$(basename "$LOCAL_REPO_PATH")"
    
    # Upload to instance
    log "Uploading to instance..."
    scp -i "$SSH_KEY" -P "$SSH_PORT" -o StrictHostKeyChecking=no \
        vesper_repo.tar.gz "$SSH_USER@$SSH_HOST:~/"
    
    # Extract on instance
    SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no $SSH_USER@$SSH_HOST"
    $SSH_CMD "tar xzf vesper_repo.tar.gz && rm vesper_repo.tar.gz"
    
    rm vesper_repo.tar.gz
    log "Repository uploaded"
}

# Build and run tests
run_tests() {
    log "Building and running tests on instance..."
    
    local SSH_INFO=$(cat .vast_ssh_info)
    local SSH_HOST=$(echo "$SSH_INFO" | cut -d':' -f1)
    local SSH_PORT=$(echo "$SSH_INFO" | cut -d':' -f2)
    local SSH_USER=$(echo "$SSH_INFO" | cut -d':' -f3)
    
    SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no $SSH_USER@$SSH_HOST"
    
    $SSH_CMD << 'ENDSSH'
        set -e
        cd Vesper
        
        echo "=== Building Vesper with AVX optimizations ==="
        mkdir -p build
        cd build
        
        # Configure with release mode and native optimizations
        cmake .. \
            -DCMAKE_BUILD_TYPE=Release \
            -DCMAKE_CXX_COMPILER=g++ \
            -DCMAKE_C_COMPILER=gcc \
            -DCMAKE_CXX_FLAGS="-O3 -march=native -mtune=native -mavx2 -mfma -fopenmp" \
            -DVESPER_BUILD_GTESTS=ON
        
        # Build the library
        make vesper_core -j$(nproc)
        
        echo "=== Building performance tests ==="
        
        # Build the performance test
        g++ -std=c++20 -O3 -march=native -mtune=native -mavx2 -mfma -fopenmp \
            -I../include -o actual_perf_test \
            ../tests/unit/actual_index_performance_test.cpp \
            libvesper_core.a -pthread -lomp
        
        # Build minimal test
        g++ -std=c++20 -O3 -march=native -mtune=native -mavx2 -mfma -fopenmp \
            -I../include -o minimal_test \
            ../tests/unit/minimal_test.cpp \
            libvesper_core.a -pthread -lomp
        
        echo "=== Running performance tests ==="
        
        # Run tests and save output
        echo "=== System Information ===" > test_results.txt
        lscpu >> test_results.txt
        echo "" >> test_results.txt
        echo "=== Compiler Version ===" >> test_results.txt
        g++ --version >> test_results.txt
        echo "" >> test_results.txt
        
        echo "=== Minimal Test Results ===" >> test_results.txt
        ./minimal_test >> test_results.txt 2>&1
        echo "" >> test_results.txt
        
        echo "=== Actual Index Performance Test Results ===" >> test_results.txt
        ./actual_perf_test >> test_results.txt 2>&1
        echo "" >> test_results.txt
        
        # Run integration test if it exists
        if [ -f integration_test ]; then
            make integration_test
            echo "=== Integration Test Results ===" >> test_results.txt
            ./integration_test >> test_results.txt 2>&1
        fi
        
        echo "Tests completed successfully!"
ENDSSH
    
    log "Tests completed"
}

# Download results
download_results() {
    log "Downloading results..."
    
    local SSH_INFO=$(cat .vast_ssh_info)
    local SSH_HOST=$(echo "$SSH_INFO" | cut -d':' -f1)
    local SSH_PORT=$(echo "$SSH_INFO" | cut -d':' -f2)
    local SSH_USER=$(echo "$SSH_INFO" | cut -d':' -f3)
    
    mkdir -p "$RESULTS_DIR"
    
    # Download test results
    scp -i "$SSH_KEY" -P "$SSH_PORT" -o StrictHostKeyChecking=no \
        "$SSH_USER@$SSH_HOST:~/Vesper/build/test_results.txt" \
        "$RESULTS_DIR/"
    
    # Get CPU info for reference
    SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no $SSH_USER@$SSH_HOST"
    $SSH_CMD "lscpu" > "$RESULTS_DIR/cpu_info.txt"
    $SSH_CMD "cat /proc/cpuinfo | grep -m1 'model name'" >> "$RESULTS_DIR/cpu_info.txt"
    
    log "Results downloaded to $RESULTS_DIR"
}

# Cleanup instance
cleanup_instance() {
    log "Cleaning up..."
    
    if [ -f .vast_contract_id ]; then
        CONTRACT_ID=$(cat .vast_contract_id)
        log "Destroying instance $CONTRACT_ID..."
        $VAST_CLI destroy instance "$CONTRACT_ID"
        rm -f .vast_contract_id .vast_ssh_info
    fi
    
    log "Cleanup complete"
}

# Main execution
main() {
    echo "======================================"
    echo "   Vast.ai Performance Test Runner   "
    echo "======================================"
    
    check_prerequisites
    
    # Set trap to cleanup on exit
    trap cleanup_instance EXIT
    
    # Run the workflow
    rent_instance
    setup_instance
    upload_repository
    run_tests
    download_results
    
    echo ""
    echo "======================================"
    echo "         Test Results Summary         "
    echo "======================================"
    
    if [ -f "$RESULTS_DIR/test_results.txt" ]; then
        # Extract and display key metrics
        echo ""
        grep -A20 "Performance Summary" "$RESULTS_DIR/test_results.txt" || true
        echo ""
        echo "Full results saved in: $RESULTS_DIR/test_results.txt"
    fi
    
    log "All tests completed successfully!"
}

# Run main function
main "$@"