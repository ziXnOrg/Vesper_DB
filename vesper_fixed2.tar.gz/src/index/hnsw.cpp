#include "vesper/index/hnsw.hpp"
#include "vesper/kernels/dispatch.hpp"
#include "vesper/kernels/batch_distances.hpp"
#include "vesper/core/memory_pool.hpp"

#include <algorithm>
#include <queue>
#include <random>
#include <unordered_set>
#include <mutex>
#include <fstream>
#include <cmath>
#include <thread>

namespace vesper::index {

/** \brief Node in HNSW graph. */
struct HnswNode {
    std::uint64_t id;
    std::vector<float> data;
    std::vector<std::vector<std::uint32_t>> neighbors;  // Per level
    std::uint32_t level;
    std::atomic<bool> deleted{false};
};

/** \brief Internal implementation of HNSW index. */
class HnswIndex::Impl {
public:
    Impl() = default;
    ~Impl() = default;
    
    /** \brief Index configuration and state. */
    struct State {
        bool initialized{false};
        std::size_t dim{0};
        HnswBuildParams params;
        std::size_t max_elements{0};
        std::size_t n_elements{0};
        std::uint32_t entry_point{std::numeric_limits<std::uint32_t>::max()};
        float level_multiplier{1.0f / std::log(2.0f)};
        std::mt19937 rng;
    } state_;
    
    /** \brief Graph nodes. */
    std::vector<std::unique_ptr<HnswNode>> nodes_;
    std::unordered_map<std::uint64_t, std::uint32_t> id_to_idx_;
    mutable std::mutex graph_mutex_;
    
    /** \brief Initialize index. */
    auto init(std::size_t dim, const HnswBuildParams& params,
              std::size_t max_elements)
        -> std::expected<void, core::error>;
    
    /** \brief Add vector to index. */
    auto add(std::uint64_t id, const float* data)
        -> std::expected<void, core::error>;
    
    /** \brief Search for nearest neighbors. */
    auto search(const float* query, const HnswSearchParams& params) const
        -> std::expected<std::vector<std::pair<std::uint64_t, float>>, core::error>;
    
    /** \brief Batch search. */
    auto search_batch(const float* queries, std::size_t n_queries,
                      const HnswSearchParams& params) const
        -> std::expected<std::vector<std::vector<std::pair<std::uint64_t, float>>>, core::error>;
    
private:
    /** \brief Select random level for new node. */
    auto select_level() -> std::uint32_t;
    
    /** \brief Search layer for nearest neighbors. */
    auto search_layer(const float* query, std::uint32_t entry_point,
                     std::uint32_t num_closest, std::uint32_t layer,
                     const std::uint8_t* filter = nullptr) const
        -> std::vector<std::pair<float, std::uint32_t>>;
    
    /** \brief Get neighbors at level. */
    auto get_neighbors(std::uint32_t idx, std::uint32_t level) const
        -> std::vector<std::uint32_t>;
    
    /** \brief Connect new node to graph. */
    auto connect_node(std::uint32_t new_idx, 
                     const std::vector<std::pair<float, std::uint32_t>>& candidates,
                     std::uint32_t M, std::uint32_t level) -> void;
    
    /** \brief Prune connections of a node. */
    auto prune_connections(std::uint32_t idx, std::uint32_t level,
                           std::uint32_t max_connections) -> void;
    
    /** \brief Compute distance between vectors. */
    auto compute_distance(const float* a, const float* b) const -> float;
    
    /** \brief Check if node passes filter. */
    auto passes_filter(std::uint32_t idx, const std::uint8_t* filter,
                       std::size_t filter_size) const -> bool;
};

auto HnswIndex::Impl::init(std::size_t dim, const HnswBuildParams& params,
                           std::size_t max_elements)
    -> std::expected<void, core::error> {
    using core::error;
    using core::error_code;
    
    if (dim == 0) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "Dimension must be > 0",
            "hnsw"
        });
    }
    
    if (params.M < 2) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "M must be >= 2",
            "hnsw"
        });
    }
    
    if (params.efConstruction < params.M) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "efConstruction must be >= M",
            "hnsw"
        });
    }
    
    state_.dim = dim;
    state_.params = params;
    state_.max_elements = max_elements;
    state_.n_elements = 0;
    state_.rng.seed(params.seed);
    state_.initialized = true;
    
    if (max_elements > 0) {
        nodes_.reserve(max_elements);
    }
    
    return {};
}

auto HnswIndex::Impl::select_level() -> std::uint32_t {
    std::uniform_real_distribution<float> dist(0.0f, 1.0f);
    const float f = -std::log(dist(state_.rng)) * state_.level_multiplier;
    return static_cast<std::uint32_t>(f);
}

auto HnswIndex::Impl::compute_distance(const float* a, const float* b) const -> float {
    const auto& ops = kernels::select_backend_auto();
    return ops.l2_sq(std::span(a, state_.dim), std::span(b, state_.dim));
}

auto HnswIndex::Impl::passes_filter(std::uint32_t idx, const std::uint8_t* filter,
                                    std::size_t filter_size) const -> bool {
    if (!filter || filter_size == 0) return true;
    
    const std::size_t byte_idx = idx / 8;
    const std::uint8_t bit_idx = idx % 8;
    
    if (byte_idx >= filter_size) return false;
    
    return (filter[byte_idx] & (1 << bit_idx)) != 0;
}

auto HnswIndex::Impl::search_layer(const float* query, std::uint32_t entry_point,
                                   std::uint32_t num_closest, std::uint32_t layer,
                                   const std::uint8_t* filter) const
    -> std::vector<std::pair<float, std::uint32_t>> {
    
    std::unordered_set<std::uint32_t> visited;
    std::priority_queue<std::pair<float, std::uint32_t>> candidates;
    std::priority_queue<std::pair<float, std::uint32_t>> nearest;
    
    const float entry_dist = compute_distance(query, nodes_[entry_point]->data.data());
    candidates.emplace(-entry_dist, entry_point);
    nearest.emplace(entry_dist, entry_point);
    visited.insert(entry_point);
    
    while (!candidates.empty()) {
        const auto [neg_dist, current] = candidates.top();
        const float current_dist = -neg_dist;
        candidates.pop();
        
        if (current_dist > nearest.top().first) {
            break;
        }
        
        const auto& neighbors = nodes_[current]->neighbors[layer];
        
        for (std::uint32_t neighbor : neighbors) {
            if (visited.count(neighbor) > 0) continue;
            visited.insert(neighbor);
            
            if (nodes_[neighbor]->deleted.load()) continue;
            if (filter && !passes_filter(neighbor, filter, 0)) continue;
            
            const float dist = compute_distance(query, nodes_[neighbor]->data.data());
            
            if (dist < nearest.top().first || nearest.size() < num_closest) {
                candidates.emplace(-dist, neighbor);
                nearest.emplace(dist, neighbor);
                
                if (nearest.size() > num_closest) {
                    nearest.pop();
                }
            }
        }
    }
    
    std::vector<std::pair<float, std::uint32_t>> result;
    while (!nearest.empty()) {
        result.push_back(nearest.top());
        nearest.pop();
    }
    
    std::reverse(result.begin(), result.end());
    return result;
}

auto HnswIndex::Impl::connect_node(std::uint32_t new_idx,
                                   const std::vector<std::pair<float, std::uint32_t>>& candidates,
                                   std::uint32_t M, std::uint32_t level) -> void {
    
    auto& new_neighbors = nodes_[new_idx]->neighbors[level];
    new_neighbors.clear();
    
    // Select M neighbors using heuristic
    std::vector<std::uint32_t> selected;
    
    if (state_.params.extend_candidates) {
        // Use RobustPrune for better connectivity
        auto candidates_copy = candidates;
        auto [pruned, extended] = robust_prune(candidates_copy, M, true, false);
        selected = std::move(pruned);
    } else {
        // Simple selection of M nearest
        for (std::size_t i = 0; i < std::min(static_cast<std::size_t>(M), candidates.size()); ++i) {
            selected.push_back(candidates[i].second);
        }
    }
    
    // Add bidirectional connections
    for (std::uint32_t neighbor : selected) {
        new_neighbors.push_back(neighbor);
        nodes_[neighbor]->neighbors[level].push_back(new_idx);
        
        // Prune neighbor's connections if needed
        const std::uint32_t max_conn = (level == 0) ? state_.params.max_M0 : state_.params.max_M;
        if (nodes_[neighbor]->neighbors[level].size() > max_conn) {
            prune_connections(neighbor, level, max_conn);
        }
    }
}

auto HnswIndex::Impl::prune_connections(std::uint32_t idx, std::uint32_t level,
                                        std::uint32_t max_connections) -> void {
    auto& neighbors = nodes_[idx]->neighbors[level];
    if (neighbors.size() <= max_connections) return;
    
    // Collect all neighbors with distances
    std::vector<std::pair<float, std::uint32_t>> candidates;
    const float* node_data = nodes_[idx]->data.data();
    
    for (std::uint32_t neighbor : neighbors) {
        const float dist = compute_distance(node_data, nodes_[neighbor]->data.data());
        candidates.emplace_back(dist, neighbor);
    }
    
    // Prune to max_connections using heuristic
    if (state_.params.extend_candidates) {
        auto [pruned, extended] = robust_prune(candidates, max_connections, false, false);
        neighbors = std::move(pruned);
    } else {
        std::sort(candidates.begin(), candidates.end());
        neighbors.clear();
        for (std::size_t i = 0; i < max_connections; ++i) {
            neighbors.push_back(candidates[i].second);
        }
    }
}

auto HnswIndex::Impl::add(std::uint64_t id, const float* data)
    -> std::expected<void, core::error> {
    using core::error;
    using core::error_code;
    
    if (!state_.initialized) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "Index not initialized",
            "hnsw"
        });
    }
    
    std::lock_guard<std::mutex> lock(graph_mutex_);
    
    if (id_to_idx_.count(id) > 0) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "ID already exists",
            "hnsw"
        });
    }
    
    const std::uint32_t new_idx = state_.n_elements++;
    const std::uint32_t level = select_level();
    
    // Create new node
    auto node = std::make_unique<HnswNode>();
    node->id = id;
    node->data.assign(data, data + state_.dim);
    node->level = level;
    node->neighbors.resize(level + 1);
    
    nodes_.push_back(std::move(node));
    id_to_idx_[id] = new_idx;
    
    // First node becomes entry point
    if (new_idx == 0) {
        state_.entry_point = 0;
        return {};
    }
    
    // Search for nearest neighbors at all levels
    std::vector<std::pair<float, std::uint32_t>> nearest;
    std::uint32_t curr_nearest = state_.entry_point;
    
    // Search upper layers
    for (std::int32_t lc = nodes_[state_.entry_point]->level; lc > static_cast<std::int32_t>(level); --lc) {
        nearest = search_layer(data, curr_nearest, 1, lc, nullptr);
        if (!nearest.empty()) {
            curr_nearest = nearest[0].second;
        }
    }
    
    // Insert at all levels
    for (std::int32_t lc = std::min(level, nodes_[state_.entry_point]->level); lc >= 0; --lc) {
        nearest = search_layer(data, curr_nearest, state_.params.efConstruction, lc, nullptr);
        
        const std::uint32_t M = (lc == 0) ? state_.params.max_M0 : state_.params.max_M;
        connect_node(new_idx, nearest, M, lc);
        
        if (!nearest.empty()) {
            curr_nearest = nearest[0].second;
        }
    }
    
    // Update entry point if new node has higher level
    if (level > nodes_[state_.entry_point]->level) {
        state_.entry_point = new_idx;
    }
    
    return {};
}

auto HnswIndex::Impl::search(const float* query, const HnswSearchParams& params) const
    -> std::expected<std::vector<std::pair<std::uint64_t, float>>, core::error> {
    using core::error;
    using core::error_code;
    
    if (!state_.initialized || state_.n_elements == 0) {
        return std::unexpected(error{
            error_code::precondition_failed,
            "Index not initialized or empty",
            "hnsw"
        });
    }
    
    std::uint32_t curr_nearest = state_.entry_point;
    
    // Search upper layers
    for (std::int32_t lc = nodes_[state_.entry_point]->level; lc > 0; --lc) {
        auto nearest = search_layer(query, curr_nearest, 1, lc, params.filter_mask);
        if (!nearest.empty()) {
            curr_nearest = nearest[0].second;
        }
    }
    
    // Search base layer with efSearch
    auto candidates = search_layer(query, curr_nearest, params.efSearch, 0, params.filter_mask);
    
    // Convert to output format
    std::vector<std::pair<std::uint64_t, float>> results;
    results.reserve(std::min(static_cast<std::size_t>(params.k), candidates.size()));
    
    for (std::size_t i = 0; i < std::min(static_cast<std::size_t>(params.k), candidates.size()); ++i) {
        const auto& [dist, idx] = candidates[i];
        results.emplace_back(nodes_[idx]->id, dist);
    }
    
    return results;
}

auto HnswIndex::Impl::search_batch(const float* queries, std::size_t n_queries,
                                   const HnswSearchParams& params) const
    -> std::expected<std::vector<std::vector<std::pair<std::uint64_t, float>>>, core::error> {
    
    std::vector<std::vector<std::pair<std::uint64_t, float>>> results(n_queries);
    
    #pragma omp parallel for
    for (std::size_t i = 0; i < n_queries; ++i) {
        const float* query = queries + i * state_.dim;
        auto result = search(query, params);
        
        if (result.has_value()) {
            results[i] = std::move(result.value());
        }
    }
    
    return results;
}

// HnswIndex public interface implementation

HnswIndex::HnswIndex() : impl_(std::make_unique<Impl>()) {}
HnswIndex::~HnswIndex() = default;
HnswIndex::HnswIndex(HnswIndex&&) noexcept = default;
HnswIndex& HnswIndex::operator=(HnswIndex&&) noexcept = default;

auto HnswIndex::init(std::size_t dim, const HnswBuildParams& params,
                    std::size_t max_elements)
    -> std::expected<void, core::error> {
    return impl_->init(dim, params, max_elements);
}

auto HnswIndex::add(std::uint64_t id, const float* data)
    -> std::expected<void, core::error> {
    return impl_->add(id, data);
}

auto HnswIndex::add_batch(const std::uint64_t* ids, const float* data, std::size_t n)
    -> std::expected<void, core::error> {
    for (std::size_t i = 0; i < n; ++i) {
        if (auto result = add(ids[i], data + i * impl_->state_.dim); !result.has_value()) {
            return result;
        }
    }
    return {};
}

auto HnswIndex::search(const float* query, const HnswSearchParams& params) const
    -> std::expected<std::vector<std::pair<std::uint64_t, float>>, core::error> {
    return impl_->search(query, params);
}

auto HnswIndex::search_batch(const float* queries, std::size_t n_queries,
                             const HnswSearchParams& params) const
    -> std::expected<std::vector<std::vector<std::pair<std::uint64_t, float>>>, core::error> {
    return impl_->search_batch(queries, n_queries, params);
}

auto HnswIndex::get_stats() const noexcept -> HnswStats {
    HnswStats stats;
    stats.n_nodes = impl_->state_.n_elements;
    
    std::size_t total_edges = 0;
    std::size_t max_level = 0;
    std::vector<std::size_t> level_counts;
    
    for (const auto& node : impl_->nodes_) {
        if (!node) continue;
        
        max_level = std::max(max_level, static_cast<std::size_t>(node->level));
        if (level_counts.size() <= node->level) {
            level_counts.resize(node->level + 1, 0);
        }
        level_counts[node->level]++;
        
        for (const auto& neighbors : node->neighbors) {
            total_edges += neighbors.size();
        }
    }
    
    stats.n_edges = total_edges / 2;  // Bidirectional edges
    stats.n_levels = max_level + 1;
    stats.level_counts = std::move(level_counts);
    stats.avg_degree = stats.n_nodes > 0 ? 
        static_cast<float>(stats.n_edges * 2) / stats.n_nodes : 0.0f;
    
    // Estimate memory usage
    stats.memory_bytes = sizeof(Impl);
    stats.memory_bytes += impl_->nodes_.capacity() * sizeof(std::unique_ptr<HnswNode>);
    for (const auto& node : impl_->nodes_) {
        if (!node) continue;
        stats.memory_bytes += sizeof(HnswNode);
        stats.memory_bytes += node->data.capacity() * sizeof(float);
        for (const auto& neighbors : node->neighbors) {
            stats.memory_bytes += neighbors.capacity() * sizeof(std::uint32_t);
        }
    }
    
    return stats;
}

auto HnswIndex::is_initialized() const noexcept -> bool {
    return impl_->state_.initialized;
}

auto HnswIndex::dimension() const noexcept -> std::size_t {
    return impl_->state_.dim;
}

auto HnswIndex::size() const noexcept -> std::size_t {
    return impl_->state_.n_elements;
}

auto HnswIndex::mark_deleted(std::uint64_t id) -> std::expected<void, core::error> {
    using core::error;
    using core::error_code;
    
    auto it = impl_->id_to_idx_.find(id);
    if (it == impl_->id_to_idx_.end()) {
        return std::unexpected(error{
            error_code::not_found,
            "ID not found",
            "hnsw"
        });
    }
    
    impl_->nodes_[it->second]->deleted.store(true);
    return {};
}

auto HnswIndex::resize(std::size_t new_max_elements) -> std::expected<void, core::error> {
    impl_->nodes_.reserve(new_max_elements);
    impl_->state_.max_elements = new_max_elements;
    return {};
}

auto HnswIndex::optimize() -> std::expected<void, core::error> {
    // Optimization passes can be added here
    // For now, just return success
    return {};
}

auto HnswIndex::save(const std::string& path) const -> std::expected<void, core::error> {
    using core::error;
    using core::error_code;
    
    std::ofstream file(path, std::ios::binary);
    if (!file) {
        return std::unexpected(error{
            error_code::io_failed,
            "Failed to open file for writing",
            "hnsw"
        });
    }
    
    // Write header
    const char magic[] = "HNSW0001";
    file.write(magic, 8);
    
    // Write parameters and state
    file.write(reinterpret_cast<const char*>(&impl_->state_.dim), sizeof(std::size_t));
    file.write(reinterpret_cast<const char*>(&impl_->state_.params), sizeof(HnswBuildParams));
    file.write(reinterpret_cast<const char*>(&impl_->state_.n_elements), sizeof(std::size_t));
    file.write(reinterpret_cast<const char*>(&impl_->state_.entry_point), sizeof(std::uint32_t));
    
    // Write nodes
    for (std::size_t i = 0; i < impl_->state_.n_elements; ++i) {
        const auto& node = impl_->nodes_[i];
        file.write(reinterpret_cast<const char*>(&node->id), sizeof(std::uint64_t));
        file.write(reinterpret_cast<const char*>(&node->level), sizeof(std::uint32_t));
        file.write(reinterpret_cast<const char*>(node->data.data()), 
                  impl_->state_.dim * sizeof(float));
        
        // Write neighbors
        for (const auto& neighbors : node->neighbors) {
            const std::size_t n_neighbors = neighbors.size();
            file.write(reinterpret_cast<const char*>(&n_neighbors), sizeof(std::size_t));
            file.write(reinterpret_cast<const char*>(neighbors.data()), 
                      n_neighbors * sizeof(std::uint32_t));
        }
    }
    
    return {};
}

auto HnswIndex::load(const std::string& /* path */) -> std::expected<HnswIndex, core::error> {
    // Full serialization will be implemented in next phase
    return HnswIndex();
}

auto HnswIndex::get_build_params() const noexcept -> HnswBuildParams {
    return impl_->state_.params;
}

auto compute_recall(const HnswIndex& index,
                   const float* queries, std::size_t n_queries,
                   const std::uint64_t* ground_truth, std::size_t k,
                   const HnswSearchParams& params) -> float {
    
    auto results = index.search_batch(queries, n_queries, params);
    if (!results.has_value()) {
        return 0.0f;
    }
    
    std::size_t total_found = 0;
    
    for (std::size_t q = 0; q < n_queries; ++q) {
        const auto& search_results = results.value()[q];
        const std::uint64_t* gt = ground_truth + q * k;
        
        for (const auto& [id, dist] : search_results) {
            for (std::size_t i = 0; i < k; ++i) {
                if (id == gt[i]) {
                    total_found++;
                    break;
                }
            }
        }
    }
    
    return static_cast<float>(total_found) / (n_queries * k);
}

auto robust_prune(
    std::vector<std::pair<float, std::uint32_t>>& candidates,
    std::uint32_t M,
    bool extend_candidates,
    bool keep_pruned)
    -> std::pair<std::vector<std::uint32_t>, std::vector<std::uint32_t>> {
    
    std::sort(candidates.begin(), candidates.end());
    
    std::vector<std::uint32_t> selected;
    std::vector<std::uint32_t> pruned;
    
    for (const auto& [dist, idx] : candidates) {
        if (selected.size() >= M) {
            if (keep_pruned) {
                pruned.push_back(idx);
            }
            continue;
        }
        
        // Check if this candidate is diverse enough
        bool is_diverse = true;
        
        // Simple heuristic: accept if nearest or adds diversity
        if (!selected.empty() && dist > candidates[0].first * 1.5f) {
            // Check angle diversity (simplified)
            is_diverse = selected.size() < M / 2;
        }
        
        if (is_diverse || selected.size() < M / 2) {
            selected.push_back(idx);
        } else if (extend_candidates && selected.size() < M) {
            selected.push_back(idx);
        } else if (keep_pruned) {
            pruned.push_back(idx);
        }
    }
    
    return {selected, pruned};
}

} // namespace vesper::index