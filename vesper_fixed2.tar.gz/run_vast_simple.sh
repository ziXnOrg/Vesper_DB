#!/bin/bash

# Simple Vast.ai Performance Test
set -euo pipefail

VAST_CLI="$HOME/.local/bin/vastai"
SSH_KEY="$HOME/.ssh/vast_ai_key"

echo "=== Vast.ai Performance Test ==="

# Find instance preferring North America for better connectivity
echo "Finding instance..."
OFFERS=$($VAST_CLI search offers 'cpu_cores>=8 cpu_ram>=16 verified=True rentable=True' --limit 50 --order 'dph' --raw)

# Try to get one from US/Canada, otherwise get cheapest
INSTANCE_ID=$(echo "$OFFERS" | jq -r '.[] | select(.geolocation | contains("CA") or contains("US")) | .ask_contract_id' | head -1)

# If no US/CA instance, get the cheapest one
if [ -z "$INSTANCE_ID" ] || [ "$INSTANCE_ID" = "null" ]; then
    INSTANCE_ID=$(echo "$OFFERS" | jq -r '.[0].ask_contract_id')
fi

if [ -z "$INSTANCE_ID" ] || [ "$INSTANCE_ID" = "null" ]; then
    echo "No suitable instances found"
    exit 1
fi

# Show instance details
INSTANCE_INFO=$(echo "$OFFERS" | jq -r '.[0] | "ID: \(.ask_contract_id), CPU: \(.cpu_name), Cores: \(.cpu_cores), RAM: \(.cpu_ram)GB, Price: $\(.dph_total)/hr"')
echo "Found instance: $INSTANCE_INFO"

echo "Creating instance $INSTANCE_ID..."
CONTRACT_ID=$($VAST_CLI create instance $INSTANCE_ID --image ubuntu:22.04 --disk 20 --ssh --raw | jq -r '.new_contract')

if [ -z "$CONTRACT_ID" ]; then
    echo "Failed to create instance"
    exit 1
fi

echo "Contract: $CONTRACT_ID"
echo "$CONTRACT_ID" > .vast_contract

# Wait for running
echo "Waiting for instance..."
for attempt in {1..20}; do
    STATUS=$($VAST_CLI show instance $CONTRACT_ID --raw | jq -r '.actual_status')
    echo "Status: $STATUS (attempt $attempt/20)"
    
    if [ "$STATUS" = "running" ]; then
        break
    fi
    
    if [ "$attempt" -eq 20 ]; then
        echo "Instance failed to start after 10 minutes"
        $VAST_CLI destroy instance $CONTRACT_ID
        exit 1
    fi
    
    sleep 30
done

# Get SSH info from vast.ai
SSH_URL=$($VAST_CLI ssh-url $CONTRACT_ID)
# Extract host and port from ssh://root@ssh6.vast.ai:13986 format
SSH_HOST=$(echo "$SSH_URL" | sed 's|ssh://root@||' | cut -d: -f1)
SSH_PORT=$(echo "$SSH_URL" | sed 's|.*:||')

echo "Connecting via $SSH_HOST:$SSH_PORT"

SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no root@$SSH_HOST"

# Wait for SSH
echo "Waiting for SSH..."
for i in {1..20}; do
    if $SSH_CMD "echo ready" 2>/dev/null; then
        break
    fi
    sleep 5
done

# Create simple test script
cat > test.sh << 'EOF'
#!/bin/bash
set -e

echo "Installing dependencies..."
apt-get update -y
apt-get install -y build-essential cmake git g++

echo "CPU Info:"
lscpu | head -10
echo ""
grep -o 'avx[^ ]*' /proc/cpuinfo | sort -u || echo "No AVX"

echo ""
echo "Extracting code..."
cd /root
tar xzf vesper.tar.gz
cd Vesper

echo "Building..."
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS="-O3 -march=native"
make vesper_core -j$(nproc)

echo "Building test..."
g++ -std=c++20 -O3 -march=native -I../include -o perf_test \
    ../tests/unit/actual_index_performance_test.cpp \
    libvesper_core.a -pthread

echo "Running performance test..."
./perf_test

echo "Complete!"
EOF

# Upload
echo "Uploading..."
tar czf vesper.tar.gz --exclude='build*' --exclude='.git' -C .. Vesper
scp -i "$SSH_KEY" -P "$SSH_PORT" -o StrictHostKeyChecking=no vesper.tar.gz test.sh root@$SSH_HOST:/root/

# Run test
echo ""
echo "=== RUNNING TEST ==="
$SSH_CMD "chmod +x test.sh && ./test.sh" | tee vast_results.txt

# Cleanup
echo ""
echo "Cleaning up..."
$VAST_CLI destroy instance $CONTRACT_ID
rm -f .vast_contract vesper.tar.gz test.sh

echo ""
echo "=== RESULTS ==="
grep -E "(Build rate|Search P|Memory:)" vast_results.txt | tail -10