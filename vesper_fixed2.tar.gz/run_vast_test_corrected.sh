#!/bin/bash

# Corrected Vast.ai Performance Testing Script for Vesper
# Usage: ./run_vast_test_corrected.sh

set -euo pipefail

# Configuration
VAST_CLI="$HOME/.local/bin/vastai"
SSH_KEY="$HOME/.ssh/vast_ai_key"
RESULTS_DIR="vast_results_$(date +%Y%m%d_%H%M%S)"

echo "======================================"
echo "   Vast.ai Performance Test Runner   "
echo "======================================"

# Check if logged in
if ! $VAST_CLI show user >/dev/null 2>&1; then
    echo "Error: Not logged in to vast.ai. Run: vastai login"
    exit 1
fi

# Step 1: Find and create instance
echo "[1/6] Finding suitable CPU instance with AVX2 support..."

# Look for CPU instances with good specs and AVX support
OFFERS=$($VAST_CLI search offers \
    'num_gpus=0 cpu_cores_effective>=8 cpu_ram>=16 has_avx=True verified=True rentable=True reliability>0.95' \
    --limit 5 --order 'dph' --raw)

if [ -z "$OFFERS" ] || [ "$OFFERS" = "[]" ]; then
    echo "Error: No suitable CPU instances found"
    exit 1
fi

# Get the cheapest offer
INSTANCE_ID=$(echo "$OFFERS" | jq -r '.[0].id')
PRICE=$(echo "$OFFERS" | jq -r '.[0].dph_total')
CPU_NAME=$(echo "$OFFERS" | jq -r '.[0].cpu_name // "Unknown"')
CPU_CORES=$(echo "$OFFERS" | jq -r '.[0].cpu_cores_effective')
RAM=$(echo "$OFFERS" | jq -r '.[0].cpu_ram')

echo "Found instance: ID=$INSTANCE_ID, CPU=$CPU_NAME, Cores=$CPU_CORES, RAM=${RAM}GB, Price=$${PRICE}/hr"

# Create the instance
echo "[2/6] Creating instance..."
CREATE_RESULT=$($VAST_CLI create instance $INSTANCE_ID --image ubuntu:22.04 --disk 20 --ssh --raw)
CONTRACT_ID=$(echo "$CREATE_RESULT" | jq -r '.new_contract // empty')

if [ -z "$CONTRACT_ID" ]; then
    echo "Error: Failed to create instance"
    echo "$CREATE_RESULT"
    exit 1
fi

echo "Created contract: $CONTRACT_ID"
echo "$CONTRACT_ID" > .vast_contract

# Wait for instance to be ready
echo "[3/6] Waiting for instance to start (this may take 2-3 minutes)..."
sleep 45

for i in {1..20}; do
    STATUS=$($VAST_CLI show instance $CONTRACT_ID --raw | jq -r '.actual_status // "unknown"')
    if [ "$STATUS" = "running" ]; then
        echo "Instance is running!"
        break
    fi
    echo "Status: $STATUS, waiting..."
    sleep 15
done

if [ "$STATUS" != "running" ]; then
    echo "Error: Instance failed to start properly (status: $STATUS)"
    $VAST_CLI destroy instance $CONTRACT_ID
    rm -f .vast_contract
    exit 1
fi

# Get SSH details
echo "[4/6] Getting SSH connection details..."
SSH_URL=$($VAST_CLI ssh-url $CONTRACT_ID)

if [ -z "$SSH_URL" ]; then
    echo "Error: Could not get SSH URL"
    $VAST_CLI destroy instance $CONTRACT_ID
    rm -f .vast_contract
    exit 1
fi

# Parse SSH URL (format: ssh -p PORT root@HOST)
SSH_PORT=$(echo "$SSH_URL" | sed -n 's/.*-p \([0-9]\+\).*/\1/p')
SSH_HOST=$(echo "$SSH_URL" | sed -n 's/.*@\([^ ]\+\).*/\1/p')
SSH_USER="root"

echo "Connecting to $SSH_HOST:$SSH_PORT"

# Setup SSH command with timeout and retries
SSH_CMD="ssh -i $SSH_KEY -p $SSH_PORT -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=10 $SSH_USER@$SSH_HOST"
SCP_CMD="scp -i $SSH_KEY -P $SSH_PORT -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

# Wait for SSH to be available
echo "[5/6] Waiting for SSH access..."
SSH_READY=false
for i in {1..30}; do
    if $SSH_CMD "echo 'Connected'" 2>/dev/null; then
        echo "SSH connection established!"
        SSH_READY=true
        break
    fi
    echo -n "."
    sleep 5
done

if [ "$SSH_READY" != "true" ]; then
    echo "Error: SSH connection failed"
    $VAST_CLI destroy instance $CONTRACT_ID
    rm -f .vast_contract
    exit 1
fi

# Setup and run tests
echo "[6/6] Running performance tests..."

# Create test script to run on remote
cat > remote_test.sh << 'SCRIPT_END'
#!/bin/bash
set -e

echo "=== Setting up environment ==="
export DEBIAN_FRONTEND=noninteractive

# Install dependencies
apt-get update -y
apt-get install -y build-essential cmake git g++ wget curl libomp-dev ninja-build

# Check CPU features
echo ""
echo "=== CPU Information ==="
lscpu | grep -E "Model name|CPU|Thread|Core|cache|Architecture"
echo ""
echo "=== SIMD Support ==="
echo "AVX support:"
grep -o 'avx[^ ]*' /proc/cpuinfo | sort -u || echo "No AVX found"
echo "SSE support:"
grep -o 'sse[^ ]*' /proc/cpuinfo | sort -u || echo "No SSE found"
echo ""

# Get Vesper code
cd /root
echo "=== Extracting Vesper repository ==="
tar xzf vesper.tar.gz
cd Vesper

# Build with optimizations
echo "=== Building Vesper with AVX optimizations ==="
mkdir -p build && cd build

# Configure with maximum optimizations
cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_COMPILER=g++ \
    -DCMAKE_C_COMPILER=gcc \
    -DCMAKE_CXX_FLAGS="-O3 -march=native -mtune=native -ffast-math -fopenmp" \
    -DVESPER_BUILD_GTESTS=OFF

# Build the core library
make vesper_core -j$(nproc)
echo "Build completed successfully!"

# Build performance tests
echo ""
echo "=== Building Performance Tests ==="

# Actual index performance test
g++ -std=c++20 -O3 -march=native -mtune=native -ffast-math -fopenmp \
    -I../include -o actual_perf_test \
    ../tests/unit/actual_index_performance_test.cpp \
    libvesper_core.a -pthread -lgomp 2>/dev/null || \
g++ -std=c++20 -O3 -march=native -mtune=native -ffast-math \
    -I../include -o actual_perf_test \
    ../tests/unit/actual_index_performance_test.cpp \
    libvesper_core.a -pthread

# Minimal test
g++ -std=c++20 -O3 -march=native -mtune=native -ffast-math \
    -I../include -o minimal_test \
    ../tests/unit/minimal_test.cpp \
    libvesper_core.a -pthread

echo "Tests built successfully!"

# Run tests
echo ""
echo "=== Running Performance Tests ==="
echo "Starting tests at $(date)"

echo ""
echo "--- Minimal Test Results ---"
timeout 300 ./minimal_test || echo "Minimal test timeout or error"

echo ""
echo "--- Actual Index Performance Test Results ---"
timeout 600 ./actual_perf_test || echo "Performance test timeout or error"

echo ""
echo "=== Tests Complete at $(date) ==="

# Show resource usage
echo ""
echo "=== Resource Usage ==="
free -h
echo ""
echo "=== Disk Usage ==="
df -h /root
SCRIPT_END

# Create tarball of repository (excluding build artifacts)
echo "Creating repository archive..."
tar czf vesper.tar.gz \
    --exclude='build*' \
    --exclude='.git' \
    --exclude='vast_*' \
    --exclude='*.o' \
    --exclude='*.a' \
    --exclude='*test' \
    --exclude='.vast_*' \
    -C .. Vesper

echo "Archive size: $(ls -lh vesper.tar.gz | awk '{print $5}')"

# Upload files
echo "Uploading code and test script..."
$SCP_CMD vesper.tar.gz "$SSH_USER@$SSH_HOST:/root/" &
$SCP_CMD remote_test.sh "$SSH_USER@$SSH_HOST:/root/" &
wait

# Run the test script and capture output
echo ""
echo "======================================"
echo "Starting remote execution..."
echo "======================================"

mkdir -p "$RESULTS_DIR"

# Run tests with timeout and save output
if timeout 900 $SSH_CMD "chmod +x /root/remote_test.sh && /root/remote_test.sh" | tee "$RESULTS_DIR/test_output.txt"; then
    echo "Tests completed successfully!"
else
    echo "Warning: Tests may have timed out or encountered errors"
fi

# Get additional system info
echo ""
echo "Collecting system information..."
$SSH_CMD "lscpu; echo ''; cat /proc/cpuinfo | head -20" > "$RESULTS_DIR/cpu_detailed.txt" 2>/dev/null || true
$SSH_CMD "free -h; echo ''; df -h" > "$RESULTS_DIR/system_info.txt" 2>/dev/null || true

# Cleanup instance
echo ""
echo "======================================"
echo "Cleaning up..."
$VAST_CLI destroy instance $CONTRACT_ID
rm -f .vast_contract vesper.tar.gz remote_test.sh

echo ""
echo "======================================"
echo "Test complete! Results saved in $RESULTS_DIR/"
echo "======================================"

# Show summary if available
if [ -f "$RESULTS_DIR/test_output.txt" ]; then
    echo ""
    echo "=== PERFORMANCE SUMMARY ==="
    
    # Extract key metrics
    if grep -q "Performance Summary" "$RESULTS_DIR/test_output.txt"; then
        grep -A20 "Performance Summary" "$RESULTS_DIR/test_output.txt" | head -20
    fi
    
    # Check for success
    if grep -q "ALL TARGETS MET" "$RESULTS_DIR/test_output.txt"; then
        echo ""
        echo "🎉 ✅ ALL PERFORMANCE TARGETS ACHIEVED!"
    elif grep -q "Performance Summary" "$RESULTS_DIR/test_output.txt"; then
        echo ""
        echo "⚠️  Some performance targets not fully met (but may still be good!)"
    else
        echo ""
        echo "❓ Could not determine final results - check $RESULTS_DIR/test_output.txt"
    fi
    
    # Show CPU info
    if [ -f "$RESULTS_DIR/cpu_detailed.txt" ]; then
        echo ""
        echo "=== CPU USED ==="
        head -3 "$RESULTS_DIR/cpu_detailed.txt"
    fi
fi

echo ""
echo "Full results available in: $RESULTS_DIR/"
SCRIPT_END